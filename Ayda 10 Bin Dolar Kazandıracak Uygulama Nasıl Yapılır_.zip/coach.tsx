import { ScrollView, Text, View, TouchableOpacity, TextInput } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function CoachScreen() {
  const colors = useColors();

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* Header */}
        <View className="px-6 pt-6 pb-4 border-b border-border">
          <View className="flex-row items-center gap-3">
            <View className="bg-primary/10 rounded-full p-3">
              <IconSymbol name="brain" size={32} color={colors.primary} />
            </View>
            <View>
              <Text className="text-2xl font-bold text-foreground">AI Finans Koçu</Text>
              <Text className="text-muted text-sm">Kişisel finansal asistanınız</Text>
            </View>
          </View>
        </View>

        <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
          {/* Quick Questions */}
          <View className="py-6 gap-3">
            <Text className="text-sm font-semibold text-muted mb-2">HIZLI SORULAR</Text>
            
            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <Text className="text-foreground font-medium">💰 Nasıl daha fazla tasarruf edebilirim?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <Text className="text-foreground font-medium">📊 Bütçemi nasıl optimize edebilirim?</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <Text className="text-foreground font-medium">📈 Yatırım önerilerini göster</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <Text className="text-foreground font-medium">🎯 Finansal durumumu analiz et</Text>
            </TouchableOpacity>
          </View>

          {/* Chat Messages */}
          <View className="gap-4 mb-6">
            {/* AI Message */}
            <View className="flex-row gap-3">
              <View className="bg-primary/10 rounded-full w-10 h-10 items-center justify-center">
                <IconSymbol name="brain" size={20} color={colors.primary} />
              </View>
              <View className="flex-1 bg-primary/5 rounded-2xl rounded-tl-sm p-4 border border-primary/10">
                <Text className="text-foreground leading-relaxed">
                  Merhaba! Ben senin AI finans koçunum. Finansal hedeflerine ulaşmana yardımcı olmak için buradayım. 
                  Bütçe planlaması, tasarruf stratejileri veya harcama alışkanlıkların hakkında sorularını sorabilirsin.
                </Text>
              </View>
            </View>

            {/* User Message */}
            <View className="flex-row gap-3 justify-end">
              <View className="flex-1 bg-primary rounded-2xl rounded-tr-sm p-4 max-w-[80%]">
                <Text className="text-white leading-relaxed">
                  Bu ay bütçemi aştım, ne yapmalıyım?
                </Text>
              </View>
            </View>

            {/* AI Response */}
            <View className="flex-row gap-3">
              <View className="bg-primary/10 rounded-full w-10 h-10 items-center justify-center">
                <IconSymbol name="brain" size={20} color={colors.primary} />
              </View>
              <View className="flex-1 bg-primary/5 rounded-2xl rounded-tl-sm p-4 border border-primary/10">
                <Text className="text-foreground leading-relaxed mb-3">
                  Analizlerime göre bu ay en çok "Yiyecek & İçecek" kategorisinde harcama yaptın (₺2,450). 
                  İşte önerilerim:
                </Text>
                <View className="gap-2">
                  <View className="flex-row items-start gap-2">
                    <Text className="text-primary">•</Text>
                    <Text className="text-foreground flex-1">Haftada 2-3 gün evde yemek yaparak ₺400-600 tasarruf edebilirsin</Text>
                  </View>
                  <View className="flex-row items-start gap-2">
                    <Text className="text-primary">•</Text>
                    <Text className="text-foreground flex-1">Kahve harcamalarını azaltarak aylık ₺200 tasarruf mümkün</Text>
                  </View>
                  <View className="flex-row items-start gap-2">
                    <Text className="text-primary">•</Text>
                    <Text className="text-foreground flex-1">Gelecek ay için "Yiyecek & İçecek" bütçeni ₺1,800'e düşürmeyi dene</Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Suggestion Card */}
            <View className="bg-success/10 rounded-2xl p-4 border border-success/20">
              <View className="flex-row items-center gap-2 mb-2">
                <IconSymbol name="target" size={20} color={colors.success} />
                <Text className="text-success font-bold">Aksiyon Önerisi</Text>
              </View>
              <Text className="text-foreground mb-3">
                "Yemek Planı" hedefi oluştur ve haftalık ₺150 tasarruf et
              </Text>
              <TouchableOpacity 
                className="bg-success rounded-full py-2 px-4 self-start"
                activeOpacity={0.7}
              >
                <Text className="text-white font-semibold">Hedef Oluştur</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View className="h-24" />
        </ScrollView>

        {/* Input Bar */}
        <View className="px-6 pb-6 pt-3 border-t border-border">
          <View className="flex-row items-center gap-3">
            <View className="flex-1 bg-surface rounded-full px-5 py-3 border border-border">
              <TextInput
                placeholder="Bir soru sor..."
                placeholderTextColor={colors.muted}
                className="text-foreground"
                style={{ fontSize: 16 }}
              />
            </View>
            <TouchableOpacity 
              className="bg-primary rounded-full w-12 h-12 items-center justify-center"
              activeOpacity={0.7}
            >
              <IconSymbol name="paperplane.fill" size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScreenContainer>
  );
}
