# WealthMind - Uygulama Tasarım Planı

## Genel Bakış

WealthMind, AI destekli kişisel finans ve zihinsel wellness'ı birleştiren bir mobil uygulamadır. Kullanıcıların finansal hedeflerine ulaşmalarına yardımcı olurken, finansal stres yönetimi ve zihinsel sağlık desteği sunar.

## Tasarım Prensipleri

- **Mobil öncelikli**: Portrait (9:16) oryantasyon, tek elle kullanım
- **Apple HIG uyumlu**: iOS native uygulama hissi
- **Minimal ve temiz**: Finansal verilerin net görünümü
- **Kişiselleştirilmiş**: AI destekli öneriler ve içgörüler
- **Motivasyonel**: Kullanıcıyı hedeflerine ulaşmaya teşvik eden tasarım

## Renk Paleti

### Ana Renkler
- **Primary (Mavi-Yeşil)**: `#0a7ea4` - Güven, büyüme, finansal istikrar
- **Success (Yeşil)**: `#22C55E` - Başarı, kazanç, pozitif gelişme
- **Warning (Turuncu)**: `#F59E0B` - Dikkat, bütçe uyarıları
- **Error (Kırmızı)**: `#EF4444` - Harcama limiti aşımı, uyarılar

### Nötr Renkler
- **Background**: `#ffffff` (açık), `#151718` (koyu)
- **Surface**: `#f5f5f5` (açık), `#1e2022` (koyu)
- **Foreground**: `#11181C` (açık), `#ECEDEE` (koyu)
- **Muted**: `#687076` (açık), `#9BA1A6` (koyu)

## Ekran Listesi ve İçerik

### 1. Ana Ekran (Dashboard)
**Amaç**: Finansal durumun hızlı özeti ve AI önerileri

**İçerik**:
- Hoşgeldin mesajı ve günlük motivasyon
- Toplam bakiye kartı (tüm hesaplar)
- Bu ay gelir/gider özeti (grafik)
- AI önerisi kartı (günlük kişiselleştirilmiş öneri)
- Hızlı eylemler: Harcama ekle, Gelir ekle, Hedef görüntüle
- Son işlemler listesi (son 5)

**Etkileşimler**:
- Bakiye kartına tıklama → Hesaplar ekranı
- AI öneri kartına tıklama → Detaylı öneri modal
- Hızlı eylem butonları → İlgili ekleme formları
- Son işlem öğesine tıklama → İşlem detayı

### 2. İşlemler Ekranı (Transactions)
**Amaç**: Tüm gelir ve giderleri görüntüleme ve yönetme

**İçerik**:
- Filtre seçenekleri (tarih, kategori, tip)
- Aylık toplam gelir/gider özeti
- Kategori bazlı harcama dağılımı (pasta grafik)
- İşlem listesi (tarih bazlı gruplandırılmış)
- Floating action button (FAB) - Yeni işlem ekle

**Etkileşimler**:
- Filtre butonuna tıklama → Filtre modal
- İşlem öğesine tıklama → İşlem detayı ve düzenleme
- İşlem öğesine swipe → Sil
- FAB tıklama → Yeni işlem ekleme formu

### 3. Bütçe Ekranı (Budget)
**Amaç**: Kategori bazlı bütçe belirleme ve takip

**İçerik**:
- Toplam aylık bütçe kartı
- Kategori bazlı bütçe kartları:
  - Kategori adı ve ikonu
  - Harcanan / Bütçe (progress bar)
  - Kalan gün sayısı
- AI bütçe önerisi (optimize edilmiş bütçe dağılımı)
- Bütçe oluştur/düzenle butonu

**Etkileşimler**:
- Kategori kartına tıklama → Kategori detayı ve işlemler
- Progress bar renk kodlaması: Yeşil (<70%), Turuncu (70-90%), Kırmızı (>90%)
- AI öneri kartına tıklama → Önerilen bütçe planı modal

### 4. Hedefler Ekranı (Goals)
**Amaç**: Finansal hedef belirleme ve ilerleme takibi

**İçerik**:
- Aktif hedefler listesi:
  - Hedef adı ve ikonu
  - Mevcut tutar / Hedef tutar
  - İlerleme yüzdesi (progress ring)
  - Tahmini tamamlanma tarihi
- Tamamlanan hedefler (daraltılabilir)
- Yeni hedef oluştur butonu

**Etkileşimler**:
- Hedef kartına tıklama → Hedef detayı ve katkı geçmişi
- Hedef kartına uzun basma → Katkı ekle hızlı modal
- Yeni hedef butonu → Hedef oluşturma formu

### 5. Wellness Ekranı (Wellness)
**Amaç**: Finansal stres yönetimi ve zihinsel sağlık desteği

**İçerik**:
- Finansal wellness skoru (0-100, dairesel gösterge)
- Bugünün wellness ipucu (AI destekli)
- Stres seviyesi takibi (haftalık grafik)
- Wellness aktiviteleri:
  - Nefes egzersizi
  - Finansal meditasyon (sesli rehber)
  - Günlük finansal günlük (journal)
- Başarı rozetleri (gamification)

**Etkileşimler**:
- Wellness skoru tıklama → Detaylı analiz
- Aktivite kartına tıklama → Aktivite başlat
- Rozet tıklama → Başarı geçmişi

### 6. AI Koç Ekranı (AI Coach)
**Amaç**: Kişiselleştirilmiş finansal rehberlik ve sohbet

**İçerik**:
- Chat arayüzü (WhatsApp benzeri)
- Önceden tanımlı hızlı sorular:
  - "Nasıl daha fazla tasarruf edebilirim?"
  - "Bütçemi nasıl optimize edebilirim?"
  - "Yatırım önerilerini göster"
  - "Finansal durumumu analiz et"
- AI yanıtları (metin + grafikler/kartlar)
- Sesli mesaj desteği (opsiyonel)

**Etkileşimler**:
- Hızlı soru tıklama → AI yanıtı
- Metin girişi → Özel soru sorma
- AI önerisindeki aksiyon butonları → İlgili ekrana yönlendirme

### 7. İstatistikler Ekranı (Insights)
**Amaç**: Detaylı finansal analiz ve raporlar

**İçerik**:
- Zaman aralığı seçici (haftalık, aylık, yıllık)
- Gelir vs Gider trend grafiği (çizgi grafik)
- Kategori bazlı harcama trendi
- En çok harcama yapılan kategoriler (bar chart)
- Aylık karşılaştırma (bu ay vs geçen ay)
- PDF rapor indir butonu (premium)

**Etkileşimler**:
- Zaman aralığı değiştirme → Grafikleri güncelle
- Grafik öğesine tıklama → Detaylı veri
- PDF indir → Premium özellik kontrolü

### 8. Profil Ekranı (Profile)
**Amaç**: Kullanıcı ayarları ve hesap yönetimi

**İçerik**:
- Kullanıcı bilgileri (ad, email)
- Abonelik durumu kartı:
  - Mevcut plan (Free / Premium)
  - Premium'a yükselt butonu (free kullanıcılar için)
  - Abonelik yönetimi (premium kullanıcılar için)
- Ayarlar:
  - Bildirimler
  - Para birimi
  - Dil
  - Tema (açık/koyu)
  - Biyometrik kilit
- Hakkında ve destek
- Çıkış yap

**Etkileşimler**:
- Abonelik kartına tıklama → Abonelik planları ekranı
- Ayar öğesine tıklama → İlgili ayar ekranı
- Çıkış yap → Onay modal

### 9. Abonelik Planları Ekranı (Subscription)
**Amaç**: Premium özellikleri tanıtma ve satın alma

**İçerik**:
- Özellik karşılaştırma tablosu (Free vs Premium)
- Premium özellikler:
  - ✓ Sınırsız AI koçluk
  - ✓ Gelişmiş analitik ve raporlar
  - ✓ Özel yatırım önerileri
  - ✓ Öncelikli destek
  - ✓ PDF rapor indirme
  - ✓ Reklamsız deneyim
- Fiyatlandırma kartları:
  - Aylık: $9.99/ay
  - Yıllık: $79.99/yıl (%33 indirim)
- 7 gün ücretsiz deneme vurgusu
- Satın alma butonları

**Etkileşimler**:
- Plan kartı seçimi → Seçili plan vurgulama
- Satın al butonu → Uygulama içi satın alma akışı
- Özellik detayı → Açıklama modal

## Kullanıcı Akışları

### Ana Kullanıcı Akışı 1: Harcama Ekleme
1. Ana Ekran → "Harcama Ekle" hızlı eylem butonu
2. Harcama ekleme formu açılır:
   - Tutar girişi (büyük, vurgulu)
   - Kategori seçimi (ikonlu grid)
   - Açıklama (opsiyonel)
   - Tarih seçici
3. "Kaydet" butonu → Haptic feedback
4. Ana ekrana dön, güncellenen bakiye ve son işlemler

### Ana Kullanıcı Akışı 2: AI Önerisi Alma
1. Ana Ekran → AI öneri kartına tıklama
2. Detaylı öneri modal açılır:
   - Öneri başlığı
   - Açıklama ve gerekçe
   - Aksiyon önerileri (butonlar)
3. Aksiyon butonuna tıklama → İlgili ekrana yönlendirme
4. Modal kapatma → Ana ekrana dön

### Ana Kullanıcı Akışı 3: Hedef Oluşturma
1. Hedefler Ekranı → "Yeni Hedef" butonu
2. Hedef oluşturma formu:
   - Hedef adı
   - Hedef tutar
   - Hedef tarih
   - Kategori/ikon seçimi
3. "Oluştur" butonu → Haptic feedback
4. Hedefler ekranına dön, yeni hedef listede görünür

### Ana Kullanıcı Akışı 4: Premium'a Yükseltme
1. Profil Ekranı → "Premium'a Yükselt" butonu
2. Abonelik Planları Ekranı açılır
3. Plan seçimi (aylık veya yıllık)
4. "Satın Al" butonu → Uygulama içi satın alma
5. Başarılı satın alma → Başarı modal + Konfeti animasyonu
6. Profil ekranına dön, güncellenmiş abonelik durumu

## Navigasyon Yapısı

### Tab Bar (Ana Navigasyon)
- **Ana Sayfa** (house.fill) - Dashboard
- **İşlemler** (list.bullet) - Transactions
- **Hedefler** (target) - Goals
- **AI Koç** (brain) - AI Coach
- **Profil** (person.fill) - Profile

### Ek Ekranlar (Stack Navigation)
- Bütçe Ekranı (Ana Sayfa'dan erişilebilir)
- Wellness Ekranı (Ana Sayfa'dan erişilebilir)
- İstatistikler Ekranı (İşlemler'den erişilebilir)
- Abonelik Planları (Profil'den erişilebilir)

## Önemli Notlar

- **Yerel Depolama**: AsyncStorage kullanarak tüm veriler cihazda saklanır
- **Backend kullanılmaz**: Kullanıcı hesapları veya bulut senkronizasyonu yok
- **AI önerileri**: Sunucu tarafında LLM kullanarak oluşturulur (API çağrısı)
- **Abonelik**: Uygulama içi satın alma ile yönetilir
- **Veri gizliliği**: Tüm finansal veriler cihazda kalır, güvenli ve özel
