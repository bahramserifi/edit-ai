import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function GoalsScreen() {
  const colors = useColors();

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-3xl font-bold text-foreground mb-2">Hedefler</Text>
          <Text className="text-muted">Finansal hedeflerinizi belirleyin ve takip edin</Text>
        </View>

        <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
          {/* Active Goals */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-foreground mb-4">Aktif Hedefler</Text>

            {/* Goal Card 1 */}
            <TouchableOpacity 
              className="bg-surface rounded-3xl p-5 mb-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center gap-3">
                  <View className="bg-primary/10 rounded-full p-3">
                    <IconSymbol name="house.fill" size={28} color={colors.primary} />
                  </View>
                  <View>
                    <Text className="text-foreground font-bold text-lg">Ev Peşinatı</Text>
                    <Text className="text-muted text-sm">6 ay kaldı</Text>
                  </View>
                </View>
                <Text className="text-primary font-bold text-2xl">65%</Text>
              </View>

              <View className="mb-3">
                <View className="bg-border rounded-full h-3 overflow-hidden">
                  <View className="bg-primary h-full" style={{ width: '65%' }} />
                </View>
              </View>

              <View className="flex-row justify-between">
                <Text className="text-muted text-sm">₺65,000 / ₺100,000</Text>
                <TouchableOpacity activeOpacity={0.7}>
                  <Text className="text-primary text-sm font-semibold">Katkı Ekle +</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            {/* Goal Card 2 */}
            <TouchableOpacity 
              className="bg-surface rounded-3xl p-5 mb-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center gap-3">
                  <View className="bg-success/10 rounded-full p-3">
                    <IconSymbol name="heart.fill" size={28} color={colors.success} />
                  </View>
                  <View>
                    <Text className="text-foreground font-bold text-lg">Acil Durum Fonu</Text>
                    <Text className="text-muted text-sm">3 ay kaldı</Text>
                  </View>
                </View>
                <Text className="text-success font-bold text-2xl">82%</Text>
              </View>

              <View className="mb-3">
                <View className="bg-border rounded-full h-3 overflow-hidden">
                  <View className="bg-success h-full" style={{ width: '82%' }} />
                </View>
              </View>

              <View className="flex-row justify-between">
                <Text className="text-muted text-sm">₺24,600 / ₺30,000</Text>
                <TouchableOpacity activeOpacity={0.7}>
                  <Text className="text-success text-sm font-semibold">Katkı Ekle +</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            {/* Goal Card 3 */}
            <TouchableOpacity 
              className="bg-surface rounded-3xl p-5 mb-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center gap-3">
                  <View className="bg-warning/10 rounded-full p-3">
                    <IconSymbol name="calendar" size={28} color={colors.warning} />
                  </View>
                  <View>
                    <Text className="text-foreground font-bold text-lg">Tatil Planı</Text>
                    <Text className="text-muted text-sm">4 ay kaldı</Text>
                  </View>
                </View>
                <Text className="text-warning font-bold text-2xl">38%</Text>
              </View>

              <View className="mb-3">
                <View className="bg-border rounded-full h-3 overflow-hidden">
                  <View className="bg-warning h-full" style={{ width: '38%' }} />
                </View>
              </View>

              <View className="flex-row justify-between">
                <Text className="text-muted text-sm">₺5,700 / ₺15,000</Text>
                <TouchableOpacity activeOpacity={0.7}>
                  <Text className="text-warning text-sm font-semibold">Katkı Ekle +</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </View>

          {/* Completed Goals */}
          <View className="mb-6">
            <TouchableOpacity 
              className="flex-row items-center justify-between mb-4"
              activeOpacity={0.7}
            >
              <Text className="text-lg font-semibold text-foreground">Tamamlanan Hedefler</Text>
              <IconSymbol name="chevron.right" size={20} color={colors.muted} />
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-success/5 rounded-2xl p-4 border border-success/20"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center gap-3">
                <View className="bg-success/20 rounded-full p-3">
                  <IconSymbol name="creditcard.fill" size={24} color={colors.success} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Kredi Kartı Borcu</Text>
                  <Text className="text-muted text-sm">₺12,000 • 2 ay önce tamamlandı</Text>
                </View>
                <Text className="text-success text-2xl">✓</Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Motivational Card */}
          <View className="bg-primary/10 rounded-3xl p-6 mb-6 border border-primary/20">
            <Text className="text-primary text-lg font-bold mb-2">💪 Harika Gidiyorsun!</Text>
            <Text className="text-foreground leading-relaxed">
              Bu ay hedeflerine toplam ₺2,450 katkı yaptın. Hedeflerinin %65'ine ulaştın!
            </Text>
          </View>

          <View className="h-20" />
        </ScrollView>

        {/* New Goal Button */}
        <TouchableOpacity 
          className="absolute bottom-6 right-6 bg-primary rounded-full w-16 h-16 items-center justify-center shadow-lg"
          activeOpacity={0.8}
          style={{
            shadowColor: colors.primary,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <IconSymbol name="plus.circle.fill" size={32} color="white" />
        </TouchableOpacity>
      </View>
    </ScreenContainer>
  );
}
