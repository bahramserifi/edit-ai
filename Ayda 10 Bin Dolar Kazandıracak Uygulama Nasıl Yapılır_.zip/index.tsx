import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function DashboardScreen() {
  const colors = useColors();

  return (
    <ScreenContainer>
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-6 gap-6">
          {/* Header */}
          <View className="gap-1">
            <Text className="text-3xl font-bold text-foreground">Merhaba! 👋</Text>
            <Text className="text-base text-muted">Bugün finansal hedeflerinize bir adım daha yaklaşın</Text>
          </View>

          {/* Balance Card */}
          <View className="bg-primary rounded-3xl p-6 shadow-sm">
            <Text className="text-white/80 text-sm font-medium mb-2">Toplam Bakiye</Text>
            <Text className="text-white text-4xl font-bold mb-4">₺12,450.00</Text>
            <View className="flex-row gap-4">
              <View className="flex-1">
                <Text className="text-white/70 text-xs mb-1">Bu Ay Gelir</Text>
                <Text className="text-white text-lg font-semibold">₺8,500</Text>
              </View>
              <View className="flex-1">
                <Text className="text-white/70 text-xs mb-1">Bu Ay Gider</Text>
                <Text className="text-white text-lg font-semibold">₺5,230</Text>
              </View>
            </View>
          </View>

          {/* AI Suggestion Card */}
          <TouchableOpacity 
            className="bg-surface rounded-2xl p-5 border border-border"
            activeOpacity={0.7}
          >
            <View className="flex-row items-center gap-3 mb-3">
              <View className="bg-primary/10 rounded-full p-2">
                <IconSymbol name="brain" size={24} color={colors.primary} />
              </View>
              <Text className="text-lg font-semibold text-foreground flex-1">AI Öneriniz</Text>
            </View>
            <Text className="text-muted leading-relaxed">
              Bu ay yemek kategorisinde bütçenizin %85'ini kullandınız. Haftada 2 gün evde yemek yaparak ₺400 tasarruf edebilirsiniz.
            </Text>
            <Text className="text-primary text-sm font-medium mt-3">Detayları Gör →</Text>
          </TouchableOpacity>

          {/* Quick Actions */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Hızlı İşlemler</Text>
            <View className="flex-row gap-3">
              <TouchableOpacity 
                className="flex-1 bg-error/10 rounded-2xl p-4 items-center gap-2"
                activeOpacity={0.7}
              >
                <IconSymbol name="arrow.down.circle.fill" size={32} color={colors.error} />
                <Text className="text-foreground font-medium">Harcama Ekle</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                className="flex-1 bg-success/10 rounded-2xl p-4 items-center gap-2"
                activeOpacity={0.7}
              >
                <IconSymbol name="arrow.up.circle.fill" size={32} color={colors.success} />
                <Text className="text-foreground font-medium">Gelir Ekle</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Recent Transactions */}
          <View className="gap-3">
            <View className="flex-row items-center justify-between">
              <Text className="text-lg font-semibold text-foreground">Son İşlemler</Text>
              <TouchableOpacity activeOpacity={0.7}>
                <Text className="text-primary text-sm font-medium">Tümünü Gör</Text>
              </TouchableOpacity>
            </View>
            
            <View className="bg-surface rounded-2xl overflow-hidden border border-border">
              {/* Transaction Item 1 */}
              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-error/10 rounded-full p-3 mr-3">
                  <IconSymbol name="creditcard.fill" size={24} color={colors.error} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Market Alışverişi</Text>
                  <Text className="text-muted text-sm">Bugün, 14:30</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺285.50</Text>
              </TouchableOpacity>

              {/* Transaction Item 2 */}
              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-success/10 rounded-full p-3 mr-3">
                  <IconSymbol name="dollarsign.circle.fill" size={24} color={colors.success} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Maaş Ödemesi</Text>
                  <Text className="text-muted text-sm">Dün, 09:00</Text>
                </View>
                <Text className="text-success font-bold text-lg">+₺8,500.00</Text>
              </TouchableOpacity>

              {/* Transaction Item 3 */}
              <TouchableOpacity 
                className="flex-row items-center p-4"
                activeOpacity={0.7}
              >
                <View className="bg-warning/10 rounded-full p-3 mr-3">
                  <IconSymbol name="house.fill" size={24} color={colors.warning} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Kira Ödemesi</Text>
                  <Text className="text-muted text-sm">3 gün önce</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺3,500.00</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Bottom Spacing */}
          <View className="h-4" />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
