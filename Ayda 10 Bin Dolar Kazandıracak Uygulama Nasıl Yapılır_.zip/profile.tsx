import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useState } from "react";

export default function ProfileScreen() {
  const colors = useColors();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(false);

  return (
    <ScreenContainer>
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-6 gap-6">
          {/* Header */}
          <View className="items-center gap-3">
            <View className="bg-primary/10 rounded-full w-24 h-24 items-center justify-center">
              <IconSymbol name="person.fill" size={48} color={colors.primary} />
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-foreground">Kullanıcı</Text>
              <Text className="text-muted">kullanici@email.com</Text>
            </View>
          </View>

          {/* Subscription Card */}
          <TouchableOpacity 
            className="bg-gradient-to-r from-primary to-primary/80 rounded-3xl p-6"
            activeOpacity={0.7}
            style={{ backgroundColor: colors.primary }}
          >
            <View className="flex-row items-center justify-between mb-3">
              <View>
                <Text className="text-white/80 text-sm font-medium mb-1">Mevcut Plan</Text>
                <Text className="text-white text-2xl font-bold">Ücretsiz</Text>
              </View>
              <View className="bg-white/20 rounded-full px-4 py-2">
                <Text className="text-white font-semibold">0₺/ay</Text>
              </View>
            </View>
            <Text className="text-white/90 mb-4">
              Premium'a yükselt ve tüm özelliklerin kilidini aç
            </Text>
            <View className="bg-white rounded-full py-3 items-center">
              <Text className="text-primary font-bold">Premium'a Yükselt →</Text>
            </View>
          </TouchableOpacity>

          {/* Premium Features Preview */}
          <View className="bg-surface rounded-2xl p-5 border border-border">
            <Text className="text-foreground font-bold text-lg mb-4">Premium Özellikler</Text>
            <View className="gap-3">
              <View className="flex-row items-center gap-3">
                <View className="bg-success/10 rounded-full w-8 h-8 items-center justify-center">
                  <Text className="text-success font-bold">✓</Text>
                </View>
                <Text className="text-foreground flex-1">Sınırsız AI koçluk</Text>
              </View>
              <View className="flex-row items-center gap-3">
                <View className="bg-success/10 rounded-full w-8 h-8 items-center justify-center">
                  <Text className="text-success font-bold">✓</Text>
                </View>
                <Text className="text-foreground flex-1">Gelişmiş analitik ve raporlar</Text>
              </View>
              <View className="flex-row items-center gap-3">
                <View className="bg-success/10 rounded-full w-8 h-8 items-center justify-center">
                  <Text className="text-success font-bold">✓</Text>
                </View>
                <Text className="text-foreground flex-1">Özel yatırım önerileri</Text>
              </View>
              <View className="flex-row items-center gap-3">
                <View className="bg-success/10 rounded-full w-8 h-8 items-center justify-center">
                  <Text className="text-success font-bold">✓</Text>
                </View>
                <Text className="text-foreground flex-1">Reklamsız deneyim</Text>
              </View>
            </View>
          </View>

          {/* Settings Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Ayarlar</Text>

            {/* Notifications */}
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="heart.fill" size={24} color={colors.primary} />
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold">Bildirimler</Text>
                    <Text className="text-muted text-sm">Harcama ve hedef bildirimleri</Text>
                  </View>
                </View>
                <Switch
                  value={notificationsEnabled}
                  onValueChange={setNotificationsEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor="white"
                />
              </View>
            </View>

            {/* Currency */}
            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="dollarsign.circle.fill" size={24} color={colors.primary} />
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold">Para Birimi</Text>
                    <Text className="text-muted text-sm">Türk Lirası (₺)</Text>
                  </View>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.muted} />
              </View>
            </TouchableOpacity>

            {/* Theme */}
            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="heart.fill" size={24} color={colors.primary} />
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold">Tema</Text>
                    <Text className="text-muted text-sm">Sistem varsayılanı</Text>
                  </View>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.muted} />
              </View>
            </TouchableOpacity>

            {/* Biometric Lock */}
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="gear" size={24} color={colors.primary} />
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold">Biyometrik Kilit</Text>
                    <Text className="text-muted text-sm">Face ID / Touch ID</Text>
                  </View>
                </View>
                <Switch
                  value={biometricEnabled}
                  onValueChange={setBiometricEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor="white"
                />
              </View>
            </View>
          </View>

          {/* Other Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground">Diğer</Text>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="heart.fill" size={24} color={colors.primary} />
                  <Text className="text-foreground font-semibold flex-1">Hakkında</Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.muted} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="paperplane.fill" size={24} color={colors.primary} />
                  <Text className="text-foreground font-semibold flex-1">Destek</Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.muted} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              className="bg-surface rounded-2xl p-4 border border-border"
              activeOpacity={0.7}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center gap-3 flex-1">
                  <IconSymbol name="gear" size={24} color={colors.primary} />
                  <Text className="text-foreground font-semibold flex-1">Gizlilik Politikası</Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color={colors.muted} />
              </View>
            </TouchableOpacity>
          </View>

          {/* Logout Button */}
          <TouchableOpacity 
            className="bg-error/10 rounded-2xl p-4 border border-error/20"
            activeOpacity={0.7}
          >
            <Text className="text-error font-bold text-center text-lg">Çıkış Yap</Text>
          </TouchableOpacity>

          <View className="h-4" />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
