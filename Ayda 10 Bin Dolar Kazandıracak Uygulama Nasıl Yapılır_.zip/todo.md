# WealthMind - TODO Listesi

## Temel Yapı ve Navigasyon
- [x] Tab bar navigasyonu yapılandırma (5 tab)
- [x] Ana ekran (Dashboard) temel yapısı
- [x] İşlemler ekranı temel yapısı
- [x] Hedefler ekranı temel yapısı
- [x] AI Koç ekranı temel yapısı
- [x] Profil ekranı temel yapısı

## Marka ve Görsel Kimlik
- [x] Uygulama logosu oluşturma (AI ile)
- [x] Logo dosyalarını ilgili klasörlere kopyalama
- [x] app.config.ts dosyasında marka bilgilerini güncelleme
- [x] Renk paletini theme.config.js'de özelleştirme

## Ana Ekran (Dashboard)
- [ ] Hoşgeldin mesajı ve tarih gösterimi
- [ ] Toplam bakiye kartı
- [ ] Gelir/gider özet kartı
- [ ] AI günlük öneri kartı
- [ ] Hızlı eylem butonları (Harcama ekle, Gelir ekle)
- [ ] Son işlemler listesi

## İşlemler Ekranı
- [ ] İşlem listesi görünümü
- [ ] Kategori ikonları ve renkleri
- [ ] Tarih bazlı gruplama
- [ ] Floating action button (yeni işlem)
- [ ] İşlem ekleme formu
- [ ] İşlem düzenleme ve silme
- [ ] Kategori bazlı filtreleme
- [ ] Aylık özet grafik (pasta chart)

## Bütçe Yönetimi
- [ ] Bütçe ekranı temel yapısı
- [ ] Kategori bazlı bütçe kartları
- [ ] Progress bar gösterimi
- [ ] Bütçe oluşturma formu
- [ ] Bütçe düzenleme
- [ ] Bütçe aşım uyarıları

## Hedefler
- [ ] Hedef listesi görünümü
- [ ] Progress ring gösterimi
- [ ] Hedef oluşturma formu
- [ ] Hedef detay ekranı
- [ ] Hedef katkı ekleme
- [ ] Hedef düzenleme ve silme
- [ ] Tamamlanan hedefler bölümü

## Wellness Özellikleri
- [ ] Wellness ekranı temel yapısı
- [ ] Finansal wellness skoru hesaplama
- [ ] Günlük wellness ipucu gösterimi
- [ ] Stres seviyesi takibi
- [ ] Nefes egzersizi aktivitesi
- [ ] Finansal meditasyon (sesli rehber)
- [ ] Günlük finansal journal
- [ ] Başarı rozetleri sistemi

## AI Koçluk
- [ ] Chat arayüzü tasarımı
- [ ] Hızlı soru butonları
- [ ] AI API entegrasyonu (sunucu LLM)
- [ ] Mesaj gönderme ve alma
- [ ] AI yanıtlarında grafik/kart gösterimi
- [ ] Kişiselleştirilmiş öneri algoritması

## İstatistikler ve Raporlar
- [ ] İstatistikler ekranı temel yapısı
- [ ] Gelir vs Gider trend grafiği
- [ ] Kategori bazlı harcama grafiği
- [ ] Aylık karşılaştırma
- [ ] Zaman aralığı filtreleme
- [ ] PDF rapor oluşturma (premium)

## Profil ve Ayarlar
- [ ] Kullanıcı profil bilgileri gösterimi
- [ ] Abonelik durumu kartı
- [ ] Bildirim ayarları
- [ ] Para birimi seçimi
- [ ] Dil seçimi
- [ ] Tema değiştirme (açık/koyu)
- [ ] Biyometrik kilit ayarı
- [ ] Hakkında ve destek sayfası

## Abonelik Sistemi
- [ ] Abonelik planları ekranı
- [ ] Özellik karşılaştırma tablosu
- [ ] Fiyatlandırma kartları
- [ ] Uygulama içi satın alma entegrasyonu
- [ ] Premium özellik kontrolü
- [ ] Ücretsiz deneme yönetimi
- [ ] Abonelik durumu takibi

## Veri Yönetimi
- [ ] AsyncStorage veri modeli tasarımı
- [ ] İşlemler için CRUD operasyonları
- [ ] Hedefler için CRUD operasyonları
- [ ] Bütçe için CRUD operasyonları
- [ ] Kullanıcı ayarları için storage
- [ ] Veri yedekleme ve geri yükleme

## UI/UX İyileştirmeleri
- [ ] Haptic feedback entegrasyonu
- [ ] Loading state'leri
- [ ] Error handling ve mesajları
- [ ] Boş state gösterimleri
- [ ] Animasyonlar (subtle ve smooth)
- [ ] Pull-to-refresh
- [ ] Swipe gestures

## Test ve Optimizasyon
- [ ] Tüm kullanıcı akışlarını test etme
- [ ] iOS ve Android uyumluluğu
- [ ] Performance optimizasyonu
- [ ] Accessibility kontrolleri
- [ ] Dark mode testi

## Dokümantasyon
- [ ] Gelir stratejisi rehberi hazırlama
- [ ] Kullanıcı kılavuzu oluşturma
- [ ] Pazarlama materyalleri hazırlama
