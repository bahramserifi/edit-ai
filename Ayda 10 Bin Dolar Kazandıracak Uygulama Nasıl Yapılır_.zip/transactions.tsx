import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TransactionsScreen() {
  const colors = useColors();

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-3xl font-bold text-foreground mb-4">İşlemler</Text>
          
          {/* Summary Cards */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-success/10 rounded-2xl p-4 border border-success/20">
              <Text className="text-success text-sm font-medium mb-1">Gelir</Text>
              <Text className="text-foreground text-2xl font-bold">₺8,500</Text>
            </View>
            <View className="flex-1 bg-error/10 rounded-2xl p-4 border border-error/20">
              <Text className="text-error text-sm font-medium mb-1">Gider</Text>
              <Text className="text-foreground text-2xl font-bold">₺5,230</Text>
            </View>
          </View>
        </View>

        {/* Filter Bar */}
        <View className="px-6 pb-4">
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="flex-row gap-2">
              <TouchableOpacity 
                className="bg-primary rounded-full px-4 py-2"
                activeOpacity={0.7}
              >
                <Text className="text-white font-medium">Tümü</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                className="bg-surface rounded-full px-4 py-2 border border-border"
                activeOpacity={0.7}
              >
                <Text className="text-foreground font-medium">Gelir</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                className="bg-surface rounded-full px-4 py-2 border border-border"
                activeOpacity={0.7}
              >
                <Text className="text-foreground font-medium">Gider</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                className="bg-surface rounded-full px-4 py-2 border border-border"
                activeOpacity={0.7}
              >
                <Text className="text-foreground font-medium">Bu Ay</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>

        {/* Transactions List */}
        <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
          {/* Today Section */}
          <View className="mb-6">
            <Text className="text-muted text-sm font-semibold mb-3">BUGÜN</Text>
            <View className="bg-surface rounded-2xl overflow-hidden border border-border">
              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-error/10 rounded-full p-3 mr-3">
                  <IconSymbol name="creditcard.fill" size={24} color={colors.error} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Market Alışverişi</Text>
                  <Text className="text-muted text-sm">Yiyecek & İçecek • 14:30</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺285.50</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                className="flex-row items-center p-4"
                activeOpacity={0.7}
              >
                <View className="bg-error/10 rounded-full p-3 mr-3">
                  <IconSymbol name="heart.fill" size={24} color={colors.error} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Kahve</Text>
                  <Text className="text-muted text-sm">Yiyecek & İçecek • 10:15</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺45.00</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Yesterday Section */}
          <View className="mb-6">
            <Text className="text-muted text-sm font-semibold mb-3">DÜN</Text>
            <View className="bg-surface rounded-2xl overflow-hidden border border-border">
              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-success/10 rounded-full p-3 mr-3">
                  <IconSymbol name="dollarsign.circle.fill" size={24} color={colors.success} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Maaş Ödemesi</Text>
                  <Text className="text-muted text-sm">Gelir • 09:00</Text>
                </View>
                <Text className="text-success font-bold text-lg">+₺8,500.00</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                className="flex-row items-center p-4"
                activeOpacity={0.7}
              >
                <View className="bg-warning/10 rounded-full p-3 mr-3">
                  <IconSymbol name="house.fill" size={24} color={colors.warning} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Elektrik Faturası</Text>
                  <Text className="text-muted text-sm">Faturalar • 16:45</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺320.00</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* This Week Section */}
          <View className="mb-6">
            <Text className="text-muted text-sm font-semibold mb-3">BU HAFTA</Text>
            <View className="bg-surface rounded-2xl overflow-hidden border border-border">
              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-warning/10 rounded-full p-3 mr-3">
                  <IconSymbol name="house.fill" size={24} color={colors.warning} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Kira Ödemesi</Text>
                  <Text className="text-muted text-sm">Konut • 3 gün önce</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺3,500.00</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                className="flex-row items-center p-4 border-b border-border"
                activeOpacity={0.7}
              >
                <View className="bg-error/10 rounded-full p-3 mr-3">
                  <IconSymbol name="creditcard.fill" size={24} color={colors.error} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Online Alışveriş</Text>
                  <Text className="text-muted text-sm">Alışveriş • 4 gün önce</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺450.00</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                className="flex-row items-center p-4"
                activeOpacity={0.7}
              >
                <View className="bg-error/10 rounded-full p-3 mr-3">
                  <IconSymbol name="heart.fill" size={24} color={colors.error} />
                </View>
                <View className="flex-1">
                  <Text className="text-foreground font-semibold mb-1">Restoran</Text>
                  <Text className="text-muted text-sm">Yiyecek & İçecek • 5 gün önce</Text>
                </View>
                <Text className="text-error font-bold text-lg">-₺280.00</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View className="h-20" />
        </ScrollView>

        {/* Floating Action Button */}
        <TouchableOpacity 
          className="absolute bottom-6 right-6 bg-primary rounded-full w-16 h-16 items-center justify-center shadow-lg"
          activeOpacity={0.8}
          style={{
            shadowColor: colors.primary,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.3,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <IconSymbol name="plus.circle.fill" size={32} color="white" />
        </TouchableOpacity>
      </View>
    </ScreenContainer>
  );
}
